basic.cv2<-function(X, Y, k,xi=0.01,nb_cores=10){
  accuracy<-vector(mode = "numeric", length = k)
  folds <- cut(seq(1,nrow(data)),breaks=k,labels=FALSE)
  accuracy<-mclapply(1:k, function(i) sub_cv(X, Y, folds, i, xi),mc.cores=nb_cores)
  list( estimateur = basic.mle(X, Y, xi)$estimateur,
        accuracy = mean(unlist(accuracy))
  )
}

basic.modelcomparison2<-function(X, Y,ListofModels, k, xi=0.001,nb_cores=10){
  scores<-vector(mode = "numeric", length = length(ListofModels))
  scores<-mclapply(1:length(ListofModels), function(i) basic.cv(X[, ListofModels[[i]]], Y, k, xi)$accuracy,mc.cores=nb_cores)
  list( estimateur = ListofModels[which.max(scores)],
        accuracy = unlist(scores[which.max(scores)])
  )
}

basic.modelselection2<-function(X, Y, direction="forward", k, xi){
  if (sum(X[,1])!=nrow(X)){
    X<-cbind(1,X)
  }
  if (direction=="forward"){
    used_variables<-1
    not_used_variables<-2:ncol(X)
    score<-0
    while(length(not_used_variables)>0){
      not_used_variables<-setdiff(unlist(not_used_variables), unlist(used_variables))
      possible_models<-list()
      for (var in 1:length(not_used_variables)){
        possible_models[[var]]<-c(unlist(used_variables), unlist(not_used_variables[var]))
      }
      best_model<-basic.modelcomparison2(X, Y,possible_models, k, xi)
      if (best_model$accuracy>score){
        score<-best_model$accuracy
        used_variables<-best_model$estimateur
      } else {
        break
      }      
    }
  } else if (direction=="backward") {
  } else {
    stop("Direction misspelled")
  }
  used_variables
}