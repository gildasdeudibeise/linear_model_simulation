basic.modelselection<-function(X, Y, direction="forward", k, xi){
  if (sum(X[,1])!=nrow(X)){
    X<-cbind(1,X)
  }
  if (direction=="forward"){
    used_variables<-1
    not_used_variables<-2:ncol(X)
    score<-0
    while(length(not_used_variables)>0){
      not_used_variables<-setdiff(not_used_variables, used_variables)
      possible_models<-list()
      for (var in 1:length(not_used_variables)){
        possible_models[[var]]<-basic.cv(X[,c(used_variables,not_used_variables[var])],Y, k, xi)
      }
      if (max(unlist(lapply(1:length(possible_models), function(x) possible_models[[x]]$accuracy)))>score){
        index<-which.max(unlist(lapply(1:length(possible_models), function(x) possible_models[[x]]$accuracy)))
        score<-possible_models[[index]]$accuracy
        used_variables<-c(used_variables,index+1)
        model_coefficients<-possible_models[[index]]$estimateur
      } else {
        break
      }
    }
  } else if (direction=="backward") {
    used_variables<-1:ncol(X)
    not_used_variables<-NULL
    score<-0
    while(length(used_variables)>0){
      used_variables<-setdiff(used_variables, not_used_variables)
      possible_models<-list()
      for (var in 1:length(used_variables)){
        possible_models[[var]]<-basic.cv(X[,used_variables[-var]],Y, k, xi)
      }
      
      if (max(unlist(lapply(1:length(possible_models), function(x) possible_models[[x]]$accuracy)))>score){
        index<-which.max(unlist(lapply(1:length(possible_models), function(x) possible_models[[x]]$accuracy)))
        score<-possible_models[[index]]$accuracy
        used_variables<-used_variables[-(index+1)]
        model_coefficients<-possible_models[[index]]$estimateur
      } else {
        break
      }
    }
  } else {
    stop("Direction misspelled")
  }
  used_variables
}