basic.modelcomparison<-function(X, Y,ListofModels, k, xi=0.001){
  scores<-vector(mode = "numeric", length = length(ListofModels))
  for (i in 1:length(ListofModels)){
    scores[i]<-basic.cv(X[, ListofModels[[i]]], Y, k, xi)$accuracy
  }
  list( estimateur = ListofModels[which.max(scores)],
        accuracy = scores[which.max(scores)]
  )
}