generate_data_X<-function(n_int, d_int){
  matrix(rnorm(n_int * d_int), n_int,d_int)
}

generate_data_Y<-function(X, constante, beta){
  z<-vector(mode = "numeric", length = nrow(X))
  for (i in 1:nrow(X)){
    z[i]=constante+sum(beta*X[i,])
  }
  z <- 1 / (1 + exp(-z))
  rbinom(nrow(X), 1, z)
}

rlogit<-function(n_int, d_int, constante, beta){
  X<-generate_data_X(n_int, d_int)
  Y<-generate_data_Y(X, constante, beta)
  as.matrix(cbind(Y,X))
}