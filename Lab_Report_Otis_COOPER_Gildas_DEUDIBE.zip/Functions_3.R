generate_data_Y2<-function(X, constante, beta){
  z<-vector(mode = "numeric", length = nrow(X))
  z=constante+as.matrix(X)%*%as.matrix(beta)
  z <- 1 / (1 + exp(-z))
  rbinom(nrow(X), 1, z)
}

rlogit2<-function(n_int, d_int, constante, beta){
  X<-generate_data_X(n_int, d_int)
  Y<-generate_data_Y2(X, constante, beta)
  as.matrix(cbind(Y,X))
}

logistiquehessienne2 <- function(x, y, param){
  z <- exp(x%*%param)
  A<-z/((1+z)^2)
  D<-diag(c(A))
  as.matrix(-(t(x)%*%D%*%x))
}

sub_cv<-function(X, Y, folds, i, xi=0.01){
  test <- which(folds==i,arr.ind=TRUE)
  mymodel<-basic.mle(X[-test,], Y[-test], xi)
  MyPredictions<-logistiquepredict(X[test,], mymodel$estimateur)
  sum(Y[test]==MyPredictions)/length(MyPredictions)
}

basic.cv1<-function(X, Y, k,xi=0.01){
  accuracy<-vector(mode = "numeric", length = k)
  folds <- cut(seq(1,nrow(data)),breaks=k,labels=FALSE)
  accuracy<-lapply(1:k, function(i) sub_cv(X, Y, folds, i, xi))
  list( Estimateur = basic.mle(X, Y, xi)$estimateur,
        accuracy = mean(unlist(accuracy))
  )
}

basic.modelcomparison1<-function(X, Y,ListofModels, k, xi=0.001){
  scores<-vector(mode = "numeric", length = length(ListofModels))
  scores<-lapply(1:length(ListofModels), function(i) basic.cv(X[, ListofModels[[i]]], Y, k, xi)$accuracy)
  list( estimateur = ListofModels[which.max(scores)],
        accuracy = unlist(scores[which.max(scores)])
  )
}
