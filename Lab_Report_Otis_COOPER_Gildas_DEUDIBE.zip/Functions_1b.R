logistiquelogvrai <- function(X, Y, param){
  z<-vector(mode = "numeric", length = nrow(X))
  z <- as.matrix(X)%*%param
  sum( Y * z - log( 1 + exp(z) ))
}

logistiquegradient <- function(x, y, param){
  grad<-vector(mode = "numeric", length = length(param))
  z <- as.matrix(x)%*%param
  z <- exp(z) / (1 + exp(z))
  for (i in 1:length(param)){
    grad[i]<-sum(x[,i] * y - x[,i] * z)
  }
  grad
}

logistiquehessienne <- function(x, y, param){
  hessienne<-matrix(data = NA, nrow = length(param), ncol = length(param))
  z <- as.matrix(x)%*%param
  z <- (exp(z)) / ( (1 + exp(z))**2 )
  for (beta1 in 1:length(param)){
    for (beta2 in 1:length(param)){
      hessienne[beta1, beta2]<-sum(-x[,beta1] * x[,beta2] * z)
    }
  }
  hessienne
}

logistiquepredict <- function(x, param){
  as.numeric(x%*%param>0)
}

logistiqueestimation <- function(x, y, xi){
  param <- vector(mode = "numeric", length = ncol(x))
  repeat{
    oldparam <- param
    param <- param - as.numeric(solve(logistiquehessienne(x, y,param)) %*% logistiquegradient(x, y, param))
    if (sum( (oldparam - param) **2) < xi) {
      break
    } 
  }
  param
}

basic.mle <- function(x, y, xi = 0.001){
  estim <- logistiqueestimation(x, y, xi)
  prediction = logistiquepredict(x, estim)
  list( estimateur = estim,
        accuracy = sum(y==prediction)/length(prediction)
  )
}