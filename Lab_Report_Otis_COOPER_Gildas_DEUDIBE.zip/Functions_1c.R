basic.cv<-function(X, Y, k,xi=0.001){
  accuracy<-vector(mode = "numeric", length = k)
  folds <- cut(seq(1,nrow(data)),breaks=k,labels=FALSE)
  for(i in 1:k){
    test <- which(folds==i,arr.ind=TRUE)
    mymodel<-basic.mle(X[-test,], Y[-test], xi)
    MyPredictions<-logistiquepredict(X[test,], mymodel$estimateur)
    accuracy[i]<-sum(Y[test]==MyPredictions)/length(MyPredictions)
  }
  list( estimateur = basic.mle(X, Y, xi)$estimateur,
        accuracy = mean(accuracy)
  )
}