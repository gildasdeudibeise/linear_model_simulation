test <- function(X, Y, param=ncol(X)){
  if (length(param)>ncol(X)){
    do.call(return, list("Length of coefficients is too long"), envir = sys.frame(-1))
  }
  if (length(Y)!=nrow(X)){
    do.call(return, list("Lengths X and Y are different"), envir = sys.frame(-1))
  }
}

logistiquegradient <- function(x, y, param){
  test(x, y, param)
  grad<-vector(mode = "numeric", length = length(param))
  z <- as.matrix(x)%*%param
  z <- exp(z) / (1 + exp(z))
  for (i in 1:length(param)){
    grad[i]<-sum(x[,i] * y - x[,i] * z)
  }
  grad
}

logistiquehessienne <- function(x, y, param){
  test(x, y, param)
  hessienne<-matrix(data = NA, nrow = length(param), ncol = length(param))
  z <- as.matrix(x)%*%param
  z <- (exp(z)) / ( (1 + exp(z))**2 )
  for (beta1 in 1:length(param)){
    for (beta2 in 1:length(param)){
      hessienne[beta1, beta2]<-sum(-x[,beta1] * x[,beta2] * z)
    }
  }
  hessienne
}
