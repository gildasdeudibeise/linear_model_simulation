parameter_estimator<-function(sample_size, nb_batch, d_int, constante, param, xi){
  list_models<-list()
  for (n in 1:length(sample_size)){
    list_batch<-list()
    for(i in 1:nb_batch){
      data<-rlogit(sample_size[[n]], d_int, constante, param)
      X=data[, -1]
      Y=data[, 1]
      list_batch[[i]]=as.numeric(basic.mle(cbind(1,X),Y, xi)$estimateur)
    }
    list_models[[n]]<-list_batch
  }
  list_models
}

model_estimator<-function(sample_size, nb_batch, d_int, constante, param, methode, k, xi){
  list_models<-list()
  for (n in 1:length(sample_size)){
    list_batch<-list()
    for(i in 1:nb_batch){
      data<-rlogit(sample_size[[n]], d_int, constante, param)
      X=data[, -1]
      Y=data[, 1]
      list_batch[[i]]=basic.modelselection2(cbind(1,X),Y, methode, k, xi)
    }
    list_models[[n]]<-list_batch
  }
  list_models
}

parameter_graph<-function(graphdata, paramfull, xlab, ylab, title){
  boxplot(graphdata, xlab=xlab, ylab=ylab, main=title)
  x0s <- 1:4 - 0.4
  x1s <- 1:4 + 0.4
  y0s <- paramfull
  segments(x0 = x0s, x1 = x1s, y0 = y0s, col = "red")
}
