generate_data_X<-function(n_int, d_int){
  matrix(rnorm(n_int * d_int), n_int,d_int)
}

generate_data_Y<-function(X, constante, beta){
  z<-vector(mode = "numeric", length = nrow(X))
  for (i in 1:nrow(X)){
    z[i]=constante+sum(beta*X[i,])
  }
  z <- 1 / (1 + exp(-z))
  rbinom(nrow(X), 1, z)
}

rlogit<-function(n_int, d_int, constante, beta){
  X<-generate_data_X(n_int, d_int)
  Y<-generate_data_Y(X, constante, beta)
  as.matrix(cbind(Y,X))
}


set.seed(123)
n_int=2000
d_int_non_zeros=10
d_int_zeros=6
d_int=d_int_non_zeros+d_int_zeros
constante=0.8

#randomise the order of the zeros in the coefficients
param=sample(c(rnorm(d_int_non_zeros), rep(0, d_int_zeros)), replace = FALSE)
paramfull=c(constante, param)

#we generate the data
data<-rlogit(n_int, d_int, constante, param)

#we make sure our data has generated properly
#summary(data)
#head(data)

#we sepperate out data for easier manipulation
X=data[, -1]
Y=data[, 1]

#saving the data
save(data, X, Y, n_int, d_int_non_zeros, d_int_zeros, d_int, constante, param, paramfull, file = "mydata.rda")
